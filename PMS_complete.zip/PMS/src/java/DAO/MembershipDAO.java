package DAO;

import Model.Membership;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class MembershipDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/databasepms";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_MEMBERSHIP_SQL = "INSERT INTO memberships (customer_id, customer_name, email, phone_num, level, application_date, expiration_date, discount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SELECT_MEMBERSHIP_BY_ID = "SELECT customer_id, customer_name, email, phone_num, level, application_date, expiration_date, discount FROM memberships WHERE customer_id = ?";
    private static final String SELECT_ALL_MEMBERSHIPS = "SELECT * FROM memberships";
    private static final String DELETE_MEMBERSHIP_SQL = "DELETE FROM memberships WHERE customer_id = ?";
    private static final String UPDATE_MEMBERSHIP_SQL = "UPDATE memberships SET customer_name = ?, email = ?, phone_num = ?, level = ?, application_date = ?, expiration_date = ?, discount = ? WHERE customer_id = ?";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
            printSQLException((SQLException) e);
        }
        return connection;
    }

    public void insertMembership(Membership membership) throws SQLException {
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_MEMBERSHIP_SQL)) {
            preparedStatement.setString(1, membership.getCustomerId());
            preparedStatement.setString(2, membership.getCustomerName());
            preparedStatement.setString(3, membership.getEmail());
            preparedStatement.setString(4, membership.getPhoneNum());
            preparedStatement.setString(5, membership.getLevel());
            preparedStatement.setDate(6, new java.sql.Date(membership.getApplicationDate().getTime()));
            preparedStatement.setDate(7, new java.sql.Date(membership.getExpirationDate().getTime()));
            preparedStatement.setDouble(8, membership.getDiscount());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Membership selectMembershipByPhone(String phoneNum) {
    Membership membership = null;
    try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM memberships WHERE phone_num = ?")) {
        preparedStatement.setString(1, phoneNum);
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            membership = new Membership();
            membership.setCustomerId(rs.getString("customer_id"));
            membership.setCustomerName(rs.getString("customer_name"));
            membership.setEmail(rs.getString("email"));
            membership.setPhoneNum(rs.getString("phone_num"));
            membership.setLevel(rs.getString("level"));
            membership.setApplicationDate(rs.getDate("application_date"));
            membership.setExpirationDate(rs.getDate("expiration_date"));
            membership.setDiscount(rs.getDouble("discount"));
        }
    } catch (SQLException e) {
        printSQLException(e);
    }
    return membership;
}

    
    public boolean isCustomerRegistered(String customerId) throws SQLException {
        boolean isRegistered = false;
        String query = "SELECT COUNT(*) FROM memberships WHERE customer_id = ?";
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, customerId);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                isRegistered = (count > 0);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return isRegistered;
    }

    public Membership selectMembership(String customerId) {
        Membership membership = null;
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MEMBERSHIP_BY_ID)) {
            preparedStatement.setString(1, customerId);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                membership = new Membership();
                membership.setCustomerId(rs.getString("customer_id"));
                membership.setCustomerName(rs.getString("customer_name"));
                membership.setEmail(rs.getString("email"));
                membership.setPhoneNum(rs.getString("phone_num"));
                membership.setLevel(rs.getString("level"));
                membership.setApplicationDate(rs.getDate("application_date"));
                membership.setExpirationDate(rs.getDate("expiration_date"));
                membership.setDiscount(rs.getDouble("discount"));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return membership;
    }

    public List<Membership> selectAllMemberships() {
        List<Membership> memberships = new ArrayList<>();
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_MEMBERSHIPS)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Membership membership = new Membership();
                membership.setCustomerId(rs.getString("customer_id"));
                membership.setCustomerName(rs.getString("customer_name"));
                membership.setEmail(rs.getString("email"));
                membership.setPhoneNum(rs.getString("phone_num"));
                membership.setLevel(rs.getString("level"));
                membership.setDiscount(rs.getDouble("discount"));
                membership.setApplicationDate(rs.getDate("application_date"));
                membership.setExpirationDate(rs.getDate("expiration_date"));
                memberships.add(membership);
            }
            // Debugging: Print out the size of the list fetched
            System.out.println("Fetched memberships: " + memberships.size());
        } catch (SQLException e) {
            printSQLException(e);
        }
        return memberships;
    }

    public boolean deleteMembership(String customerId) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_MEMBERSHIP_SQL)) {
            statement.setString(1, customerId);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateMembership(Membership membership) throws SQLException {
        boolean rowUpdated = false;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_MEMBERSHIP_SQL)) {
            statement.setString(1, membership.getCustomerName());
            statement.setString(2, membership.getEmail());
            statement.setString(3, membership.getPhoneNum());
            statement.setString(4, membership.getLevel());
            statement.setDate(5, new java.sql.Date(membership.getApplicationDate().getTime()));
            statement.setDate(6, new java.sql.Date(membership.getExpirationDate().getTime()));
            statement.setDouble(7, membership.getDiscount());
            statement.setString(8, membership.getCustomerId());
            rowUpdated = statement.executeUpdate() > 0;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
