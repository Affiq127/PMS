/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.MODEL;

/**
 *
 * @author User
 */
public class Supplier {
    private int supplierID;
    private String supplierName;
    private String supplierContact;

    public Supplier (int supplierID, String supplierName, String supplierContact){
        super();
        this.supplierID = supplierID;
        this.supplierName = supplierName;
        this.supplierContact = supplierContact;
    }
        public Supplier ( String supplierName, String supplierContact){
        super();
        this.supplierName = supplierName;
        this.supplierContact = supplierContact;
    }
    
    public Supplier(){
        
    }
    /**
     * @return the supplierID
     */
    public int getSupplierID() {
        return supplierID;
    }

    /**
     * @param supplierID the supplierID to set
     */
    public void setSupplierID(int supplierID) {
        this.supplierID = supplierID;
    }

    /**
     * @return the supplierName
     */
    public String getSupplierName() {
        return supplierName;
    }

    /**
     * @param supplierName the supplierName to set
     */
    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    /**
     * @return the supplierContact
     */
    public String getSupplierContact() {
        return supplierContact;
    }

    /**
     * @param supplierContact the supplierContact to set
     */
    public void setSupplierContact(String supplierContact) {
        this.supplierContact = supplierContact;
    }
    
}