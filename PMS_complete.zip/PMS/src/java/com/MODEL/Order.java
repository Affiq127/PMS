/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.MODEL;

/**
 *
 * @author User
 */
public class Order {
    private int orderID;
    private String orderName;
    private String orderDetails;
    private int quantity;
    private int productID;
    
    public Order(int orderID, String orderName, String orderDetails, int quantity, int productID){
        super();
        this.orderID = orderID;
        this.orderName = orderName;
        this.orderDetails = orderDetails;
        this.quantity = quantity;
        this.productID = productID;
    }
    
    public Order(String orderName, String orderDetails, int quantity, int productID){
        super();
        this.orderName = orderName;
        this.orderDetails = orderDetails;
        this.quantity = quantity;
        this.productID = productID;
    }
    
    public Order(){
        
    }
    /**
     * @return the orderID
     */
    public int getOrderID() {
        return orderID;
    }

    /**
     * @param orderID the orderID to set
     */
    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    /**
     * @return the orderName
     */
    public String getOrderName() {
        return orderName;
    }

    /**
     * @param orderName the orderName to set
     */
    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    /**
     * @return the orderDetails
     */
    public String getOrderDetails() {
        return orderDetails;
    }

    /**
     * @param orderDetails the orderDetails to set
     */
    public void setOrderDetails(String orderDetails) {
        this.orderDetails = orderDetails;
    }

    /**
     * @return the quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the productID
     */
    public int getProductID() {
        return productID;
    }

    /**
     * @param productID the productID to set
     */
    public void setProductID(int productID) {
        this.productID = productID;
    }
    
}


