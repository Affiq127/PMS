/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.WEB;

import java.sql.*;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.DAO.OrderDAO;
import com.DAO.SupplierDAO;
import com.DAO.ProductDAO;
import com.MODEL.Supplier;
import com.MODEL.Order;
import com.MODEL.Product;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author User
 */
@WebServlet("/")
public class SupplierServlet extends HttpServlet {
    private OrderDAO orderDAO;
    private SupplierDAO supplierDAO;
    private ProductDAO productDAO;
    public void init() {
        supplierDAO = new SupplierDAO();
        orderDAO = new OrderDAO();
        productDAO = new ProductDAO();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();

        try {
            switch (action) {
                case "/newSupplier":
                    showNewForm(request, response);
                    break;
                case "/insertSupplier":
                    insertSupplier(request,response);
                    break;
                case "/deleteSupplier":
                    deleteSupplier(request, response);
                    break;
                case "/editSupplier":
                    showEditForm(request, response);
                    break;
                case "/updateSupplier":
                    updateSupplier(request, response);
                    break;
                case "/insertOrder":
                    insertOrder(request, response);
                    break;
                case "/updateOrder":
                    updateOrder(request, response);
                    break;
                case "/listOrder":
                    listOrder(request, response);
                    break;
                case "/editOrder":
                    showEditOrderForm(request, response);
                    break;
                case "/newOrder":
                    showNewOrderForm(request,response);
                    break;
                case "/deleteOrder":
                    deleteOrder (request, response);
                    break;
                case "/listSupplier":
                    listSupplier(request, response);
                    break;
                case "/insertProduct":
                    insertProduct(request, response);
                    break;
                case "/listProduct":
                    listProduct(request, response);
                    break;
                case "/newProduct":
                    showNewProductForm(request,response);
                    break;
                case "/deleteProduct":
                    deleteProduct (request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listSupplier(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        List<Supplier> listSupplier = supplierDAO.selectAllSupplier();
        request.setAttribute("listSupplier", listSupplier);
        RequestDispatcher dispatcher = request.getRequestDispatcher("SupplierList.jsp");
        dispatcher.forward(request, response);
    }
    
    private void listOrder(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        List<Order> listOrder = orderDAO.selectAllOrder();
        request.setAttribute("listOrder", listOrder);
        RequestDispatcher dispatcher = request.getRequestDispatcher("OrderList.jsp");
        dispatcher.forward(request, response);
    }
    
    private void listProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        List <Product> listProduct = productDAO.selectAllProduct();
        request.setAttribute("listProduct", listProduct);
        RequestDispatcher dispatcher = request.getRequestDispatcher("ProductList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("SupplierForm.jsp");
        dispatcher.forward(request, response);
    }
    
    private void showNewOrderForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("OrderForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewProductForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("ProductForm.jsp");
        dispatcher.forward(request, response);
    }
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        int supplierID = Integer.parseInt(request.getParameter("supplierID"));
        Supplier existingSupplier = supplierDAO.selectSupplier(supplierID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("SupplierForm.jsp");
        request.setAttribute("supplier", existingSupplier);
        dispatcher.forward(request, response);
    }
    
    private void showEditOrderForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        int orderID = Integer.parseInt(request.getParameter("orderID"));
        Order existingOrder = orderDAO.selectOrder(orderID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("OrderForm.jsp");
        request.setAttribute("order", existingOrder);
        dispatcher.forward(request, response);
    }

    private void insertSupplier(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        String supplierName = request.getParameter("supplierName");
        String supplierContact = request.getParameter("supplierContact");
        Supplier newSupplier = new Supplier(supplierName, supplierContact);
        supplierDAO.insertSupplier(newSupplier);
        response.sendRedirect("listSupplier");
    }
    
    private void insertOrder(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        String orderName = request.getParameter("orderName");
        String orderDetails = request.getParameter("orderDetails");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        int productID = Integer.parseInt(request.getParameter("productID"));
        Order newOrder = new Order(orderName, orderDetails, quantity, productID);
        orderDAO.insertOrder(newOrder);
        response.sendRedirect("listOrder");
    }
    private void insertProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        String productName = request.getParameter("productName");
        double price = Double.parseDouble(request.getParameter("price"));
        int supplierID = Integer.parseInt(request.getParameter("supplierID"));
        Product newProduct = new Product(productName, price,supplierID);
        productDAO.insertProduct(newProduct);
        response.sendRedirect("listProduct");
    }

    private void updateSupplier(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int supplierID = Integer.parseInt(request.getParameter("supplierID"));
        String supplierName = request.getParameter("supplierName");
        String supplierContact = request.getParameter("supplierContact");

        Supplier supplier = new Supplier(supplierID, supplierName, supplierContact);
        supplierDAO.updateSupplier(supplier);
        response.sendRedirect("listSupplier");
    }
    
    private void updateOrder(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int orderID = Integer.parseInt(request.getParameter("orderID"));
        String orderName = request.getParameter("orderName");
        String orderDetails = request.getParameter("orderDetails");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        int productID = Integer.parseInt(request.getParameter("productID"));
        Order order = new Order(orderID, orderName, orderDetails, quantity, productID);
        orderDAO.updateOrder(order);
        response.sendRedirect("listOrder");
    }

    private void deleteSupplier(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int supplierID = Integer.parseInt(request.getParameter("supplierID"));
        supplierDAO.deleteSupplier(supplierID);
        response.sendRedirect("listSupplier");
    }

    private void deleteOrder(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int orderID = Integer.parseInt(request.getParameter("orderID"));
        orderDAO.deleteOrder(orderID);
        response.sendRedirect("listOrder");
    }
    
    private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int productID = Integer.parseInt(request.getParameter("productID"));
        productDAO.deleteProduct(productID);
        response.sendRedirect("listProduct");
    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}