/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;
import java.sql.*;
import java.util.*;
import com.MODEL.Supplier;
/**
 *
 * @author User
 */
public class SupplierDAO {
    Connection connection = null;
    private String jdbcURL ="jdbc:mysql://localhost:3306/databasepms";
    
    private static final String INSERT_SUPPLIER_SQL = "INSERT INTO suppliers (supplierName,supplierContact) VALUES (?,?)";
    
    private static final String SELECT_SUPPLIER_BY_ID = "select supplierID, supplierName, supplierContact from suppliers where supplierID=?";
    private static final String SELECT_ALL_SUPPLIER = "select * from suppliers";
    private static final String DELETE_SUPPLIER_SQL = "delete from suppliers where supplierID=?";
    private static final String UPDATE_SUPPLIER_SQL = "update suppliers set supplierName=?,supplierContact=? where supplierID=?";
    
    public SupplierDAO(){
    }
        
        public Connection getConnection(){
            Connection connection = null;
            try{
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(jdbcURL,"root","");
            }catch (SQLException e){
                e.printStackTrace();
            }catch (ClassNotFoundException e){
                e.printStackTrace();
            }
            return connection;
        }
    public void insertSupplier(Supplier supplier) throws SQLException{        
        try(Connection connection = getConnection(); PreparedStatement preparedStatement =
                connection.prepareStatement(INSERT_SUPPLIER_SQL)){
            preparedStatement.setString(1,supplier.getSupplierName());
            preparedStatement.setString(2,supplier.getSupplierContact());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            printSQLException(e);
        }
    }
    
    public Supplier selectSupplier(int supplierID){
        Supplier supplier = null;
        
        try(Connection connection = getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SUPPLIER_BY_ID);){
            preparedStatement.setInt(1,supplierID);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()){
                String supplierName = rs.getString("supplierName");
                String supplierContact = rs.getString("supplierContact");
                supplier = new Supplier (supplierID,supplierName,supplierContact);
            }
            
        }catch(SQLException e){
            printSQLException(e);
        }
        return supplier;
    }
    
    public List <Supplier> selectAllSupplier(){
        
        List<Supplier> supplier = new ArrayList <>();
        
        try (Connection connection = getConnection();
                PreparedStatement preparedStatement= connection.prepareStatement(SELECT_ALL_SUPPLIER);){
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            while (rs.next()){
                int supplierID = rs.getInt("supplierID");
                String supplierName = rs.getString("supplierName");
                String supplierContact = rs.getString("supplierContact");
                supplier.add(new Supplier(supplierID,supplierName,supplierContact));
            }
        }catch (SQLException e){
            printSQLException(e);
        }
        return supplier;
    }
    
    public boolean deleteSupplier (int supplierID) throws SQLException{
        boolean rowDeleted;
        try(Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_SUPPLIER_SQL);){
            statement.setInt(1,supplierID);
            rowDeleted = statement.executeUpdate()>0;
        }
        return rowDeleted;
    }
    
    public boolean updateSupplier (Supplier supplier) throws SQLException{
        boolean rowUpdated;
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(UPDATE_SUPPLIER_SQL);){
            statement.setString(1,supplier.getSupplierName());
            statement.setString(2,supplier.getSupplierContact());
            statement.setInt(3,supplier.getSupplierID());
            
            rowUpdated = statement.executeUpdate()>0;
        }
        return rowUpdated;
    }
    private void printSQLException(SQLException ex){
        for (Throwable e: ex){
            if (e instanceof SQLException){
                e.printStackTrace(System.err);
                System.err.println("SQLState: "+((SQLException) e).getSQLState());
                System.err.println("Error Code: "+((SQLException) e).getErrorCode());
                System.err.println("Message: "+e.getMessage());
                Throwable t = ex.getCause();
                while (t != null){
                    System.out.println("Cause: "+t);
                    t = t.getCause();
                }
            }
        }
    }

    
        
}
