/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;
import java.sql.*;
import java.util.*;
import com.MODEL.Supplier;
import com.MODEL.Order;
import com.MODEL.Product;
/**
 *
 * @author User
 */
public class ProductDAO {
    Connection connection = null;
    private String jdbcURL ="jdbc:mysql://localhost:3306/databasepms";
    
    private static final String INSERT_PRODUCT_SQL = "INSERT INTO products1 (productName,price,supplierID) VALUES (?,?,?)";
    private static final String SELECT_PRODUCT_BY_ID = "select productName,price,supplierID from products1 where productID=?";
    private static final String SELECT_ALL_PRODUCT = "select * from products1";
    private static final String DELETE_PRODUCT_SQL = "delete from products1 where productID=?";
    private static final String UPDATE_PRODUCT_SQL = "update products1 set productName=?,price=?, supplierID=? where productID=?";
    
    public ProductDAO(){
    }
        public Connection getConnection(){
            Connection connection = null;
            try{
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(jdbcURL,"root","");
            }catch (SQLException e){
                e.printStackTrace();
            }catch (ClassNotFoundException e){
                e.printStackTrace();
            }
            return connection;
        }

    
    public void insertProduct(Product product) throws SQLException{        
        try(Connection connection = getConnection(); PreparedStatement preparedStatement =
                connection.prepareStatement(INSERT_PRODUCT_SQL)){
            preparedStatement.setString(1,product.getProductName());
            preparedStatement.setDouble(2,product.getPrice());
            preparedStatement.setInt(3,product.getSupplierID());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            printSQLException(e);
        }
    }
    
    public Product selectProduct(int productID){
        Product product = null;
        
        try(Connection connection = getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PRODUCT_BY_ID);){
            preparedStatement.setInt(1,productID);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()){
                String productName = rs.getString("productName");
                double price = rs.getDouble("price");
                int supplierID = rs.getInt("supplierID");
                product = new Product (productID,productName,price,supplierID);
            }
            
        }catch(SQLException e){
            printSQLException(e);
        }
        return product;
    }
    
    public List <Product> selectAllProduct(){
        
        List<Product> product = new ArrayList <>();
        
        try (Connection connection = getConnection();
                PreparedStatement preparedStatement= connection.prepareStatement(SELECT_ALL_PRODUCT);){
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            while (rs.next()){
                int productID = rs.getInt("productID");
                String productName = rs.getString("productName");
                double price = rs.getDouble("price");
                int supplierID = rs.getInt("supplierID");
                product.add(new Product(productID,productName,price,supplierID));
            }
        }catch (SQLException e){
            printSQLException(e);
        }
        return product;
    }
    
    public boolean deleteProduct (int productID) throws SQLException{
        boolean rowDeleted;
        try(Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_PRODUCT_SQL);){
            statement.setInt(1,productID);
            rowDeleted = statement.executeUpdate()>0;
        }
        return rowDeleted;
    }
    
    public boolean updateProduct(Product product) throws SQLException{
        boolean rowUpdated;
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(UPDATE_PRODUCT_SQL);){
            statement.setString(1,product.getProductName());
            statement.setDouble(2,product.getPrice());
            statement.setInt(3,product.getSupplierID());

            
            rowUpdated = statement.executeUpdate()>0;
        }
        return rowUpdated;
    }
    
    private void printSQLException(SQLException ex){
        for (Throwable e: ex){
            if (e instanceof SQLException){
                e.printStackTrace(System.err);
                System.err.println("SQLState: "+((SQLException) e).getSQLState());
                System.err.println("Error Code: "+((SQLException) e).getErrorCode());
                System.err.println("Message: "+e.getMessage());
                Throwable t = ex.getCause();
                while (t != null){
                    System.out.println("Cause: "+t);
                    t = t.getCause();
                }
            }
        }
    }

        

}
