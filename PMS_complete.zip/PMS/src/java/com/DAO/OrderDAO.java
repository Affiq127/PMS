/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;

/**
 *
 * @author User
 */
import java.sql.*;
import java.util.*;
import com.MODEL.Supplier;
import com.MODEL.Order;
import com.MODEL.Product;
/**
 *
 * @author User
 */
public class OrderDAO {
    Connection connection = null;
    private String jdbcURL ="jdbc:mysql://localhost:3306/databasepms";
    
    private static final String INSERT_ORDER_SQL = "INSERT INTO orders (orderName,orderDetail,quantity,productID) VALUES (?,?,?,?)";
    private static final String SELECT_ORDER_BY_ID = "select orderName,orderDetail,quantity,productID from orders where orderID=?";
    private static final String SELECT_ALL_ORDER = "select * from orders";
    private static final String DELETE_ORDER_SQL = "delete from orders where orderID=?";
    private static final String UPDATE_ORDER_SQL = "update orders set orderName=?,orderDetail=?, quantity=?, productID=? where orderID=?";
    
    public OrderDAO(){
    }
        public Connection getConnection(){
            Connection connection = null;
            try{
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(jdbcURL,"root","");
            }catch (SQLException e){
                e.printStackTrace();
            }catch (ClassNotFoundException e){
                e.printStackTrace();
            }
            return connection;
        }

    
    public void insertOrder(Order order) throws SQLException{        
        try(Connection connection = getConnection(); PreparedStatement preparedStatement =
                connection.prepareStatement(INSERT_ORDER_SQL)){
            preparedStatement.setString(1,order.getOrderName());
            preparedStatement.setString(2,order.getOrderDetails());
            preparedStatement.setInt(3,order.getQuantity());
            preparedStatement.setInt(4,order.getProductID());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            printSQLException(e);
        }
    }
    
    public Order selectOrder(int orderID){
        Order order = null;
        
        try(Connection connection = getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ORDER_BY_ID);){
            preparedStatement.setInt(1,orderID);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()){
                String orderName = rs.getString("orderName");
                String orderDetails = rs.getString("orderDetails");
                int quantity = rs.getInt("quantity");
                int productID = rs.getInt("productID");
                order = new Order (orderID,orderName,orderDetails,quantity,productID);
            }
            
        }catch(SQLException e){
            printSQLException(e);
        }
        return order;
    }
    
    public List <Order> selectAllOrder(){
        
        List<Order> order = new ArrayList <>();
        
        try (Connection connection = getConnection();
                PreparedStatement preparedStatement= connection.prepareStatement(SELECT_ALL_ORDER);){
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            while (rs.next()){
                int orderID = rs.getInt("orderID");
                String orderName = rs.getString("orderName");
                String orderDetails = rs.getString("orderDetails");
                int quantity = rs.getInt("quantity");
                int productID = rs.getInt("productID");
                order.add(new Order(orderID,orderName,orderDetails,quantity,productID));
            }
        }catch (SQLException e){
            printSQLException(e);
        }
        return order;
    }
    
    public boolean deleteOrder (int orderID) throws SQLException{
        boolean rowDeleted;
        try(Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_ORDER_SQL);){
            statement.setInt(1,orderID);
            rowDeleted = statement.executeUpdate()>0;
        }
        return rowDeleted;
    }
    
    public boolean updateOrder(Order order) throws SQLException{
        boolean rowUpdated;
        try (Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(UPDATE_ORDER_SQL);){
            statement.setString(1,order.getOrderName());
            statement.setString(2,order.getOrderDetails());
            statement.setInt(3,order.getQuantity());
            statement.setInt(4,order.getProductID());
            statement.setInt(5,order.getOrderID());
            
            rowUpdated = statement.executeUpdate()>0;
        }
        return rowUpdated;
    }
    
    private void printSQLException(SQLException ex){
        for (Throwable e: ex){
            if (e instanceof SQLException){
                e.printStackTrace(System.err);
                System.err.println("SQLState: "+((SQLException) e).getSQLState());
                System.err.println("Error Code: "+((SQLException) e).getErrorCode());
                System.err.println("Message: "+e.getMessage());
                Throwable t = ex.getCause();
                while (t != null){
                    System.out.println("Cause: "+t);
                    t = t.getCause();
                }
            }
        }
    }

        

}
