/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.*;
import java.util.*;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @return
     */
    
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/databasepms","root","");
        } catch (Exception e){
            System.out.println(e);
        }
        return con;
        
        
    }
    
    public static int save(User e) {
        int status = 0;
        try {
            Connection con = LoginServlet.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "insert into users(id,password,role,name,contact) values (?,?,?,?,?)");
            ps.setString(1, e.getId());
            ps.setString(2, e.getPassword());
            ps.setString(3, e.getRole());
            ps.setString(4, e.getName());
            ps.setString(5, e.getContact());
            
            status = ps.executeUpdate();

            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    public static int update(User e) {
        int status = 0;
        try {
            Connection con = LoginServlet.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "update users set password=?,role=?,name=?,contact=? where id=?");
            ps.setString(1, e.getPassword());
            ps.setString(2, e.getRole());
            ps.setString(3, e.getName());
            ps.setString(4, e.getContact());
            ps.setString(5, e.getId());

            status = ps.executeUpdate();

            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    public static int delete(String id) {
        int status = 0;
        try {
            Connection con = LoginServlet.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from users where id=?");
            ps.setString(1, id);
            status = ps.executeUpdate();

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    public static User getUserById(String id) {
        User e = new User();

        try {
            Connection con = LoginServlet.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from users where id=?");
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                e.setId(rs.getString(1));
                e.setPassword(rs.getString(2));
                e.setRole(rs.getString(3));
                e.setName(rs.getString(4));
                e.setContact(rs.getString(5));
                
            }
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }

    public static List<User> getAllUsers() {
        List<User> list = new ArrayList<User>();

        try {
            Connection con = LoginServlet.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from users");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                User e = new User();
                e.setId(rs.getString(1));
                e.setPassword(rs.getString(2));
                e.setRole(rs.getString(3));
                e.setName(rs.getString(4));
                e.setContact(rs.getString(5));
                list.add(e);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    static User update(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        
        try{
            Connection con = LoginServlet.getConnection();
            
            
            if (role.equals("admin") || role.equals("staff")) {
        String sql = "SELECT * FROM users WHERE id = ? AND password = ? AND role = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setString(1, id);
        statement.setString(2, password);
        statement.setString(3, role);
        
        ResultSet result = statement.executeQuery();
        
        if (result.next()) {
            if (role.equals("admin")) {
                request.getRequestDispatcher("addUser.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("staffHome.jsp").forward(request, response);
            }
        } else {
            out.print("<script>alert(\"Error! Please try again!\")</script>");
            request.getRequestDispatcher("Login.jsp").include(request, response);
        }
    } else {
        out.print("<script>alert(\"Error! Invalid role!\")</script>"); 
        request.getRequestDispatcher("Login.jsp").include(request, response);
    }
    } catch (Exception e) {
        System.out.println(e);
    }
}

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
