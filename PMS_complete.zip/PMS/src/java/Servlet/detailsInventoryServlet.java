/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlet;

import Model.Product;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class detailsInventoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/databasepms";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String productID = request.getParameter("productID");

        if (productID == null || productID.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Product ID parameter is required");
            return;
        }
        
        String formattedProductID = String.format("%03d", Integer.parseInt(productID));

        System.out.println("Received productID: " + productID); 

        String pname = "N/A";
        String supplier = "N/A";
        Date expiryDate = Date.valueOf("1970-01-01"); // Default date
        double pricePerBox = 0.0;
        int quantity = 0;
        double subtotal = 0.0;

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String query = "SELECT ProductName, Supplier, ExpiryDate, PricePerBox, Quantity, Subtotal FROM products1 WHERE ProductID = ?";

            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, productID);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        pname = rs.getString("ProductName");
                        supplier = rs.getString("Supplier");
                        expiryDate = rs.getDate("ExpiryDate");
                        pricePerBox = rs.getDouble("PricePerBox");
                        quantity = rs.getInt("Quantity");
                        subtotal = rs.getDouble("Subtotal");

                        System.out.println("Product fetched from database: " + pname); // Debug statement
                    } else {
                        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Product with ID " + productID + " not found");
                        return;
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching product details");
            return;
        }

        Product product = new Product(productID, pname, supplier, expiryDate, pricePerBox, quantity, subtotal);

        request.setAttribute("product", product);

        request.getRequestDispatcher("/inventoryDetails.jsp").forward(request, response);
    }
}
