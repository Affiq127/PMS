/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlet;

import Model.Product;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class listInventoryServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/databasepms";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Product> productList = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String query = "SELECT LPAD(ProductID, 3, '0') AS FormattedProductID, ProductName, Supplier, ExpiryDate, PricePerBox, Quantity, Subtotal FROM products1";

            try (PreparedStatement ps = conn.prepareStatement(query); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String productID = rs.getString("FormattedProductID");
                    String pname = rs.getString("ProductName");
                    String supplier = rs.getString("Supplier");
                    java.sql.Date expiryDate = rs.getDate("ExpiryDate");
                    double pricePerBox = rs.getDouble("PricePerBox");
                    int quantity = rs.getInt("Quantity");
                    double subtotal = rs.getDouble("Subtotal");

                    Product product = new Product(productID, pname, supplier, expiryDate, pricePerBox, quantity, subtotal);
                    productList.add(product);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
            return;
        }

        request.setAttribute("productList", productList);
        request.getRequestDispatcher("inventoryList.jsp").forward(request, response);
    }
}
