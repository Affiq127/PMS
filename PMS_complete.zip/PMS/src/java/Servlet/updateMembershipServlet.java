package Servlet;

import DAO.MembershipDAO;
import Model.Membership;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateMembership")
public class updateMembershipServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MembershipDAO membershipDAO;

    public void init() {
        membershipDAO = new MembershipDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String custId = request.getParameter("custId");
        String custName = request.getParameter("custName");
        String email = request.getParameter("email");
        String phoneNum = request.getParameter("phoneNum");
        String applicationDateStr = request.getParameter("applicationDate");
        String level = request.getParameter("level");
        String discountStr = request.getParameter("discount");

        // Debugging: Print out the received parameters
        System.out.println("Received Parameters:");
        System.out.println("Customer ID: " + custId);
        System.out.println("Customer Name: " + custName);
        System.out.println("Email: " + email);
        System.out.println("Phone Number: " + phoneNum);
        System.out.println("Application Date: " + applicationDateStr);
        System.out.println("Level: " + level);
        System.out.println("Discount: " + discountStr);

        // Validate and parse the input
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date applicationDate = null;
        Date expirationDate = null;
        double discount = 0;

        try {
            if (applicationDateStr != null && !applicationDateStr.isEmpty()) {
                applicationDate = dateFormat.parse(applicationDateStr);
                // Calculate expiration date as one year from application date
                expirationDate = new Date(applicationDate.getTime() + (365L * 24 * 60 * 60 * 1000));
            }
            if (discountStr != null && !discountStr.isEmpty()) {
                discount = Double.parseDouble(discountStr);
            }
        } catch (ParseException | NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
            return;
        }

        Membership membership = new Membership();
        membership.setCustomerId(custId);
        membership.setCustomerName(custName);
        membership.setEmail(email);
        membership.setPhoneNum(phoneNum);
        membership.setApplicationDate(applicationDate);
        membership.setExpirationDate(expirationDate);
        membership.setLevel(level);
        membership.setDiscount(discount);

        // Update the membership in the database
        boolean success = false;
        try {
            success = membershipDAO.updateMembership(membership);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (success) {
            // Set the membership attribute and forward to viewDetails.jsp
            request.setAttribute("membership", membership);
            RequestDispatcher dispatcher = request.getRequestDispatcher("viewDetails.jsp");
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("error.jsp"); // Redirect to an error page
        }
    }
}
