package Servlet;

import Model.Product;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/InventoryServlet")
public class inventoryServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/databasepms";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pname = request.getParameter("pname");
        String supplier = request.getParameter("supplier");
        String expiryDateStr = request.getParameter("expiry_date");
        String pricePerBoxStr = request.getParameter("price_per_box");
        String quantityStr = request.getParameter("quantity");

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            Date expiryDate = expiryDateStr != null && !expiryDateStr.isEmpty() ? Date.valueOf(expiryDateStr) : null;
            BigDecimal pricePerBox = pricePerBoxStr != null && !pricePerBoxStr.isEmpty() ? new BigDecimal(pricePerBoxStr) : BigDecimal.ZERO;
            int quantity = quantityStr != null && !quantityStr.isEmpty() ? Integer.parseInt(quantityStr) : 0;
            BigDecimal subtotal = pricePerBox.multiply(new BigDecimal(quantity));

            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            String query = "INSERT INTO products1 (ProductName, Supplier, ExpiryDate, PricePerBox, Quantity, Subtotal) VALUES (?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, pname);
            ps.setString(2, supplier);
            ps.setDate(3, expiryDate);
            ps.setBigDecimal(4, pricePerBox);
            ps.setInt(5, quantity);
            ps.setBigDecimal(6, subtotal);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        long productID = generatedKeys.getLong(1);
                        String formattedProductID = String.format("%03d", productID);
                        Product product = new Product(formattedProductID, pname, supplier, expiryDate, pricePerBox.doubleValue(), quantity, subtotal.doubleValue());
                        request.setAttribute("product", product);
                        request.setAttribute("successMessage", "Product is successfully added!!");
                        request.getRequestDispatcher("inventoryDetails.jsp").forward(request, response);
                    } else {
                        throw new SQLException("Creating product failed, no ID obtained.");
                    }
                }
            } else {
                request.setAttribute("errorMessage", "Error: Unable to add product.");
                request.getRequestDispatcher("inventoryDetails.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
            request.getRequestDispatcher("inventoryDetails.jsp").forward(request, response);
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productID = request.getParameter("productID");

        if (productID == null || productID.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Product ID parameter is required");
            return;
        }

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            String query = "SELECT ProductID, ProductName, Supplier, ExpiryDate, PricePerBox, Quantity, Subtotal FROM products1 WHERE ProductID = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, productID);
            rs = ps.executeQuery();

            if (rs.next()) {
                String pname = rs.getString("ProductName");
                String supplier = rs.getString("Supplier");
                Date expiryDate = rs.getDate("ExpiryDate");
                double pricePerBox = rs.getDouble("PricePerBox");
                int quantity = rs.getInt("Quantity");
                double subtotal = rs.getDouble("Subtotal");

                String formattedProductID = String.format("%03d", rs.getInt("ProductID"));
                Product product = new Product(formattedProductID, pname, supplier, expiryDate, pricePerBox, quantity, subtotal);
                request.setAttribute("product", product);
                request.getRequestDispatcher("inventoryDetails.jsp").forward(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Product with ID " + productID + " not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching product details");
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
