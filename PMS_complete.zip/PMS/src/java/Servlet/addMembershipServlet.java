package Servlet;

import DAO.MembershipDAO;
import Model.Membership;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/addMembership")
public class addMembershipServlet extends HttpServlet {
    private MembershipDAO membershipDAO;

    public void init() {
        membershipDAO = new MembershipDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String customerName = request.getParameter("custName");
        String customerId = request.getParameter("custId");
        String email = request.getParameter("email");
        String phoneNum = request.getParameter("phoneNum");
        String level = request.getParameter("level");
        String applicationDateStr = request.getParameter("applicationDate");
        double discount = Double.parseDouble(request.getParameter("discount"));

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date applicationDate = null;
        Date expirationDate = null;
        try {
            applicationDate = sdf.parse(applicationDateStr);
            // Set expiration date based on membership level
            switch (level) {
                case "Basic":
                    expirationDate = new Date(applicationDate.getTime() + (183L * 24 * 60 * 60 * 1000)); // 6 months
                    break;
                case "Premium":
                    expirationDate = new Date(applicationDate.getTime() + (365L * 24 * 60 * 60 * 1000)); // 1 year
                    break;
                case "VIP":
                    expirationDate = new Date(applicationDate.getTime() + (730L * 24 * 60 * 60 * 1000)); // 2 years
                    break;
                default:
                    expirationDate = new Date(applicationDate.getTime() + (365L * 24 * 60 * 60 * 1000)); // default to 1 year
                    break;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // Check if customer already has an active membership
        boolean isAlreadyRegistered = false;
        try {
            isAlreadyRegistered = membershipDAO.isCustomerRegistered(customerId);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (isAlreadyRegistered) {
            // Forward to failure page indicating customer is already registered
            request.setAttribute("type", "registered");
            RequestDispatcher dispatcher = request.getRequestDispatcher("MembershipFailure.jsp");
            dispatcher.forward(request, response);
        } else {
            // Proceed with membership registration
            Membership membership = new Membership();
            membership.setCustomerName(customerName);
            membership.setCustomerId(customerId);
            membership.setEmail(email);
            membership.setPhoneNum(phoneNum);
            membership.setLevel(level);
            membership.setApplicationDate(applicationDate);
            membership.setExpirationDate(expirationDate);
            membership.setDiscount(discount);

            try {
                membershipDAO.insertMembership(membership);
                request.setAttribute("customerName", customerName);
                request.setAttribute("customerId", customerId);
                request.setAttribute("email", email);
                request.setAttribute("phoneNum", phoneNum);
                request.setAttribute("level", level);
                request.setAttribute("applicationDate", applicationDateStr);
                request.setAttribute("expirationDate", sdf.format(expirationDate));
                request.setAttribute("discount", discount);
                RequestDispatcher dispatcher = request.getRequestDispatcher("MembershipSuccess.jsp");
                dispatcher.forward(request, response);
            } catch (SQLException e) {
                e.printStackTrace();
                // Forward to failure page for general error
                request.setAttribute("type", "error");
                RequestDispatcher dispatcher = request.getRequestDispatcher("MembershipFailure.jsp");
                dispatcher.forward(request, response);
            }
        }
    }
}
