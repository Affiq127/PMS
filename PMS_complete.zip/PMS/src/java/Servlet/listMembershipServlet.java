package Servlet;

import DAO.MembershipDAO;
import Model.Membership;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.io.IOException;
import java.util.List;

@WebServlet("/membershipList")
public class listMembershipServlet extends HttpServlet {
    private MembershipDAO membershipDAO;

    public void init() {
        membershipDAO = new MembershipDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Membership> listMembership = membershipDAO.selectAllMemberships();
        request.setAttribute("listMembership", listMembership);
        RequestDispatcher dispatcher = request.getRequestDispatcher("membership-list.jsp");
        dispatcher.forward(request, response);
    }
}
