package Model;

import java.util.Date;

public class Product {
    private String productID;
    private String pname;
    private String supplier;
    private java.sql.Date expiryDate;
    private double pricePerBox;
    private int quantity;
    private double subtotal;

    // Constructor
    public Product(String productID, String pname, String supplier, java.sql.Date expiryDate, double pricePerBox, int quantity, double subtotal) {
        this.productID = productID;
        this.pname = pname;
        this.supplier = supplier;
        this.expiryDate = expiryDate;
        this.pricePerBox = pricePerBox;
        this.quantity = quantity;
        this.subtotal = subtotal;
    }

    // Getters
    public String getProductID() {
        return productID;
    }

    public String getPname() {
        return pname;
    }

    public String getSupplier() {
        return supplier;
    }

    public java.sql.Date getExpiryDate() {
        return expiryDate;
    }

    public double getPricePerBox() {
        return pricePerBox;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getSubtotal() {
        return subtotal;
    }
}
