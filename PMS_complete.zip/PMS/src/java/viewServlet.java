/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/viewServlet"})
public class viewServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.print("<html>");
            out.print("<head>");
            out.print("</head>");
            out.print("<style>");
            out.print(".header {");
            out.print("display: flex;");
            out.print("align-items: center;");
            out.print("background-color: #333;");
            out.print("color: white;");
            out.print("padding: 10px;");
            out.print("width:100%");
            out.print("}");
            out.print(".logo {");
            out.print("font-size: 24px;");
            out.print("margin-right: auto;");
            out.print("padding-left: 20px;");
            out.print("font-family: Georgia, serif;");
            out.print("}");
            //NAVBAR CSS-----------------------------------------------------------------
            out.print(".nav {");
            out.print("display: flex;");
            out.print("list-style-type: none;");
            out.print("margin: 0;");
            out.print("padding: 0;");
            out.print("}");
            out.print(".nav li {");
            out.print("margin-right: 30px;");
            out.print("}");
            out.print(".nav a {");
            out.print("color: white;");
            out.print("text-decoration: none;");
            out.print("text-align: center;");
            out.print("padding: 14px 22px;");
            out.print("display: block;");
            out.print("}");
            out.print(".nav a:hover {");
            out.print("background-color: #ddd;");
            out.print("color: black;");
            out.print("border-radius:10px");
            out.print("}");
            out.print(".nav a.active {");
            out.print("background-color: #4CAF50;");
            out.print("border-radius:10px");
            out.print("}");
            //BODY CSS----------------------------------------------------------------
            out.print("body {");
            out.print("display: grid;");
            out.print("place-items: center;");
            out.print("height: 50vh;");
            out.print("margin: 0;");
            out.print("background-color: #FFDAB9;");
            out.print("}");
            out.print("table {");
            out.print("border-collapse: separate; ");
            out.print("overflow: hidden; ");
            out.print("border: 1px solid black;");
            out.print("}");
            out.print("<style>");
            //FOOTER CSS----------------------------------------------------------------
            out.print("footer {");
            out.print("background-color: rgba(0, 0, 0, 0.5);");
            out.print("color: #fff;");
            out.print("padding: 10px;");
            out.print("display: flex;");
            out.print("justify-content: space-between;");
            out.print("align-items: center;");
            out.print("position: fixed;");
            out.print("bottom: 0;");
            out.print("width: 100%;");
            out.print("height: 2%;");
            out.print("backdrop-filter: blur(10px);");
            out.print("}");
            out.print(".footer-left {");
            out.print("display: flex;");
            out.print("align-items: center;");
            out.print("}");
            out.print("</style>");
            out.print("</style>");
            List<User> list=LoginServlet.getAllUsers();
            //BODY-----------------------------------------------------------------------------------------------------
            out.print("<body>");
            out.print("<div class='header'>");
            out.print("<div class='logo'>iCARE Pharmacy</div>");
            out.print("<ul class='nav'>");
            out.print("<li><a href=\"addUser.jsp\">Add Users</a></li>");
            out.print("<li><a class=\"active\" href='viewServlet'>View Users</a></li>");
            out.print("<a href='Login.jsp'>LogOut</a>");
            out.print("</ul>");
            out.print("</div>");
            out.println("<h1 style=\"color: #007BFF; font-size: 2em; text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1); border-bottom: 2px solid #007BFF; padding-bottom: 10px;\">User List</h1>");
            //TABLE-----------------------------------------------------------------------------------------------------
            out.print("<table bgcolor='black' border='1' width='75%'>");
            out.print("<tr bgcolor='#f6b092'><th>Id</th><th>Name</th><th>Password</th><th>Role</th>"
                    + "<th>Edit</th><th>Delete</th></tr>");
            
            for (User e : list){
                out.print("<tr bgcolor='#f6cf92'><td>" + e.getId()+ "</td><td>" + e.getName() + "</td><td>"
                          +e.getPassword() + "</td><td>" + e.getRole() + "</td><td><a href='editUser?id="
                          +e.getId() + "'>edit</a></td><td><a href='deleteUser?id="
                           +e.getId() + "'>delete</a></td></tr>");
            }
            out.print("</table");
            //FOOTER----------------------------------------------------------------------------------------------------
            out.print("<div class=\"footer\">");
            out.print("&copy; 2024 MediSync Innovations. All rights reserved.");
            out.print("</div>");            
            out.print("</body>");
            out.print("</html>");
            out.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
